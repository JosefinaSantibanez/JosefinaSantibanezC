var alturaNiño = 1;
function muestraSiElNiñoPuedeSubirALaMontañaRusa(){
    if(alturaNiño > 52){
        console.log("¡Súbete, chico!")
    }
    elif(alturaNiño < 52)
    {
        console.log("Lo siento, chico. Tal vez el próximo año”)
    }
    
}