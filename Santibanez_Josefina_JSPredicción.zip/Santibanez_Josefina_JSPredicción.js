function myBirthYearFunc(){
        console.log("Nací en " + 1980);
    }
//Predicción1: Cuando se llame a la función se mostrara el mensaje ¨Nací en 1980¨, al contrario si no es llamado no se mostrara nada. 
function myBirthYearFunc(EntradaAñoNacimiento){
        console.log("Nací en " + EntradaAñoNacimiento);
    }
//Predicción2: Si la variable EntradaAñoNacimiento es 1980 la consola mostrara el mensaje ¨Nací en 1980¨
function add(num1, num2){
        console.log("¡Sumando números!");
        console.log("num1 is: " + num1);
        console.log("num2 is: " + num2);
        var sum = num1 + num2;
        console.log(sum);
    }
    
//Predicción3: Si se llama a esta función con num1 = 10 y num2 = 20 se mostraran los siguientes mensajes: "¡Sumando números!", ¨num1 is: 10¨, ¨num2 is: 20¨, 30 